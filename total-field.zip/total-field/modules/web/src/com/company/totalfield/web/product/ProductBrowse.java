package com.company.totalfield.web.product;

import com.haulmont.cuba.gui.components.AbstractLookup;

public class ProductBrowse extends AbstractLookup {
}