package com.company.totalfield.web.service;

import com.haulmont.cuba.gui.components.AbstractEditor;
import com.company.totalfield.entity.Service;

public class ServiceEdit extends AbstractEditor<Service> {
}