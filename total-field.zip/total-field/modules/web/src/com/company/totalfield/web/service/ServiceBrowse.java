package com.company.totalfield.web.service;

import com.haulmont.cuba.gui.components.AbstractLookup;

public class ServiceBrowse extends AbstractLookup {
}