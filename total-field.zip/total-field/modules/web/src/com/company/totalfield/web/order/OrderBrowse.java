package com.company.totalfield.web.order;

import com.haulmont.cuba.gui.components.AbstractLookup;

public class OrderBrowse extends AbstractLookup {
}