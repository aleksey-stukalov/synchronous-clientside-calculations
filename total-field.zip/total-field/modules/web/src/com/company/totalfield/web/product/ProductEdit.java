package com.company.totalfield.web.product;

import com.haulmont.cuba.gui.components.AbstractEditor;
import com.company.totalfield.entity.Product;

public class ProductEdit extends AbstractEditor<Product> {
}